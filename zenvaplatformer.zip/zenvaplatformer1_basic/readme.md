HTML5 Platformer Game using Quintus
Pablo Farias Navarro
@ZenvaTweets
www.zenva.com
www.gamedevacademy.org
==================================================

Artwork licenses: 

tiles: public domain - http://opengameart.org/content/platformer-art-deluxe
